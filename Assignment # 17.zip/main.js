for (var input = 1; input <= 10; input++) {
        console.log(input);
}
/* program to generate a multiplication table
upto a range */

// take number input from the user
const number = parseInt(prompt('Enter an integer: '));

// take range input from the user
const range = parseInt(prompt('Enter a range: '));

//creating a multiplication table
for (let i = 1; i <= range; i++) {
        const result = i * number;
        console.log(`${number} × ${i} = ${result}`);
}

let array = [],
        count = 1,
        index = 0,
        i;

for (i = 0; i <= 15; i++) {
        if (index === i) {
                index += ++count;
                continue;
        }
        array.push(i);
}

document.write(array.join(' '))

function PrintReverseOrder(N)

{
        for (let i = N; i > 0; i--)
                document.write(i + " ");
}
let N = 10;
PrintReverseOrder(N);

for (var a = 0; a <=20; a++){
        if(a % 2 == 0){
                document.write(a + '<br>')
        }
}

for (var a = 0; a <=20; a++){
        if(a % 2 != 0){
                document.write(a + '<br>')
        }
}